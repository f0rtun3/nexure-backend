"""empty message

Revision ID: 49b83cacc07b
Revises: e641468fbab4, 5dc36dc922fb, 51624531bf2d
Create Date: 2019-09-23 09:58:20.485012

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '49b83cacc07b'
down_revision = None
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
